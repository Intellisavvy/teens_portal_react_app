import React from "react";

// export const PrivateLayout = () => {
//     return <h1>private layout</h1>
// }