import './App.css';
import React, { useState } from 'react';
import TextField from '@mui/material/TextField';
import Jobsearch from './joblist.json'
import { Box } from '@mui/system';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';

export const JobSearch = ()=> {
    const [name, setname] = useState({
        search: ''
     });
     const { search } = name;
     const searching = (e: any) => {
        setname({ ...name, [e.target.name]: e.target.value })
     }
    return <div>
         <div >
            <TextField
               value={search}
               name="search"
               placeholder='Search Jobs here'
               sx={{ marginLeft: "12rem", width: "40rem", marginTop: "3rem" }}
               onChange={searching} />
         </div>
         {
            Jobsearch.filter(data => data.jobtitle.toLowerCase().includes(search.toLowerCase())).map(data => {
               return (
                  <div key={data.id}>
                    
                     <Box className="well">
                        <div>
                            <td>Name</td><td>{data.OrgName}</td>
                        </div>
                        <div>
                            <td>JobTitle</td><td>{data.jobtitle}</td>
                        </div>
                        <div>
                            <td>JobDescription</td><td className='align'> {data.jobdescription}</td>
                        </div>
                        <div>
                            <td>Payment</td><td>{data.payment}</td>
                        </div>
                        <div>
                        <td >TimePeriod: </td>  <td >From:{data.fromdate}  To:{data.todate}</td>
                        </div>
                        <div>
                           <td >WorkingTime: </td><td > {data.workingtime}</td>
                        </div>
                        <div>
                           <td >JobLocation: </td> <td >{data.joblocation}</td>
                        </div>
                        <div>
                           <td >ContactDetails: </td > <td >{data.contactdetails}</td>
                        </div>
                      
                        <div>
                           <Stack spacing={2} sx={{ marginLeft: '46rem', width: "9rem", marginBottom: '2rem' }}>
                              <Button variant="contained" >Apply</Button>
                           </Stack>
                        </div>

                        {/* <div >
                           <td className='size'>  Name/Organization:</td> <td className='name'> {data.OrgName}</td>
                        </div>
                        <div>
                           <td className='size'>JobTitle:</td><td className='title'>{data.jobtitle}</td>
                        </div>
                        <div>
                           <td className='size'>JobDescription:</td> <td className='jd'> {data.jobdescription}</td>
                        </div>
                        <div >
                           <td className='size'> Payment:</td>  <td className='payment'> {data.payment}</td>
                        </div>
                        <div>
                           <td className='size'>TimePeriod: </td>  <td className='date'>From:{data.fromdate}  To:{data.todate}</td>
                        </div>
                        <div>
                           <td className='size'>WorkingTime: </td><td className='time'> {data.workingtime}</td>
                        </div>
                        <div>
                           <td className='size'>JobLocation: </td> <td className='location'>{data.joblocation}</td>
                        </div>
                        <div>
                           <td className='size'>ContactDetails: </td > <td className='contact'>{data.contactdetails}</td>
                        </div>
                        <div>
                           <Stack spacing={2} sx={{ marginLeft: '46rem', width: "9rem", marginBottom: '2rem' }}>
                              <Button variant="contained" >Apply</Button>
                           </Stack>
                        </div> */}

                     </Box>
                  </div>
                   )
                })}
      </div>
}