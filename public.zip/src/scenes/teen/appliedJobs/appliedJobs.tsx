export const AppliedJobs = () => {
    return <div>Applied job search</div>
}