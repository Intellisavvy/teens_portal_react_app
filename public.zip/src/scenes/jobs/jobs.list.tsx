import { JobCard } from "./jobCard"


export const JobsList = () => {
    return(
        <JobCard/>
    )
}