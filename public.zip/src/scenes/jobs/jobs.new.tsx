import JobPostForm from "../VendorReg/JobPostForm"

export const JobPost = () => {

    return(
        <div>
            <JobPostForm />
        </div>
    )
}