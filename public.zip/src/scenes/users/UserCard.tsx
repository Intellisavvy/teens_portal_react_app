
export const UserCard = ()=> {
    return <div>
        user card
    </div>
}