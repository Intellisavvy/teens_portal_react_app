import { Outlet } from "react-router-dom"

export const Users = ()=> {
    return <div>
        Users

        <Outlet></Outlet>
    </div>
}